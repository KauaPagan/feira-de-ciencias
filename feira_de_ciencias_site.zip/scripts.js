// scripts.js
document.addEventListener('DOMContentLoaded', function() {
    // Adicione suas funcionalidades interativas aqui
});
